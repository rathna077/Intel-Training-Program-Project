from django.shortcuts import render, redirect
from . models import UserPersonalModel
from . forms import UserPersonalForm, UserRegisterForm
from django.contrib.auth import authenticate, login,logout
from django.contrib import messages
import numpy as np
import joblib


import pyperclip
import random


# Create your views here.
def passhome(request):
    return render(request, 'passwordGenerator/passhome.html')


def password(request):

    characters = list('abcdefghijklmnopqrstuvwxyz')
    if request.GET.get('uppercase'):
        characters.extend(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'))
    if request.GET.get('numbers'):
        characters.extend(list('0123456789'))
    if request.GET.get('special'):
        characters.extend(list(r'!@#$%^&*<>?-_:'))

    length = int(request.GET.get('length', 12))
    thepassword = ''
    for x in range(length):
        thepassword += random.choice(characters)
    pyperclip.copy(thepassword)
    return render(request, 'passwordGenerator/password.html', {'password': thepassword})



def Landing_1(request):
    return render(request, '1_Landing.html')

def Register_2(request):
    form = UserRegisterForm()
    if request.method =='POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account was successfully created. ' + user)
            return redirect('Login_3')

    context = {'form':form}
    return render(request, '2_Register.html', context)


def Login_3(request):
    if request.method =='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('Home_4')
        else:
            messages.info(request, 'Username OR Password incorrect')

    context = {}
    return render(request,'3_Login.html', context)

def Home_4(request):
    return render(request, '4_Home.html')

def Teamates_5(request):
    return render(request,'5_Teamates.html')

def Domain_Result_6(request):
    return render(request,'6_Domain_Result.html')

def Problem_Statement_7(request):
    return render(request,'7_Problem_Statement.html')
    

def Per_Info_8(request):
    if request.method == 'POST':
        fieldss = ['firstname','lastname','age','address','phone','city','state','country']
        form = UserPersonalForm(request.POST)
        if form.is_valid():
            print('Saving data in Form')
            form.save()
        return render(request, '4_Home.html', {'form':form})
    else:
        print('Else working')
        form = UserPersonalForm(request.POST)    
        return render(request, '8_Per_Info.html', {'form':form})
    
    
from django.shortcuts import render
import numpy as np
import pyttsx3



def Deploy_9(request):
    if request.method == 'POST':
        from ultralytics import YOLO
        import cvzone
        import cv2
        import math
        from APP.models import DetectedVehicle
        import serial
        import time

        # Running real-time from webcam
        cap = cv2.VideoCapture(0)

        model = YOLO('C:/Users/sabee/Music/ITPCV08/DEPLOYMENT/PROJECT/APP/best.pt')
        
        # Reading the classes
        classnames = ['bus', 'car', 'motorbike', 'person', 'truck']
        frame_number = 0
        while True:
            ret, frame = cap.read()
            frame = cv2.resize(frame, (640, 480))
            result = model(frame, stream=True)
            s1 = 0

            # Getting bbox, confidence, and class names information to work with
            for info in result:
                boxes = info.boxes
                for box in boxes:
                    confidence = box.conf[0]
                    confidence = math.ceil(confidence * 100)
                    Class = int(box.cls[0])
                    if confidence > 50:
                        x1, y1, x2, y2 = box.xyxy[0]
                        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 5)
                        cvzone.putTextRect(frame, f'{classnames[Class]} {confidence}%', [x1 + 8, y1 + 100],
                                        scale=1.5, thickness=2)

                        
                        if classnames[Class] == "bus":
                            frame_number += 1
                            coordinates = f'({x1}, {y1}) to ({x2}, {y2})'
                            detected_safety = DetectedVehicle(
                                frame_number=frame_number,
                                class_name=classnames[Class],
                                confidence=confidence,
                                coordinates=coordinates
                            )
                            detected_safety.save()

                            # Print status
                            print(f"Detected: {classnames[Class]}, Confidence: {confidence}, Coordinates: {coordinates}")
                            
                        elif classnames[Class] == "car":
                            frame_number += 1
                            coordinates = f'({x1}, {y1}) to ({x2}, {y2})'
                            detected_safety = DetectedVehicle(
                                frame_number=frame_number,
                                class_name=classnames[Class],
                                confidence=confidence,
                                coordinates=coordinates
                            )
                            detected_safety.save()

                            # Print status
                            print(f"Detected: {classnames[Class]}, Confidence: {confidence}, Coordinates: {coordinates}")
                            
                        elif classnames[Class] == "motorbike":
                            frame_number += 1
                            coordinates = f'({x1}, {y1}) to ({x2}, {y2})'
                            detected_safety = DetectedVehicle(
                                frame_number=frame_number,
                                class_name=classnames[Class],
                                confidence=confidence,
                                coordinates=coordinates
                            )
                            detected_safety.save()

                            # Print status
                            print(f"Detected: {classnames[Class]}, Confidence: {confidence}, Coordinates: {coordinates}")
                            
                        elif classnames[Class] == "person":
                            frame_number += 1
                            coordinates = f'({x1}, {y1}) to ({x2}, {y2})'
                            detected_safety = DetectedVehicle(
                                frame_number=frame_number,
                                class_name=classnames[Class],
                                confidence=confidence,
                                coordinates=coordinates
                            )
                            detected_safety.save()

                            # Print status
                            print(f"Detected: {classnames[Class]}, Confidence: {confidence}, Coordinates: {coordinates}")
                            
                        elif classnames[Class] == "truck":
                            frame_number += 1
                            coordinates = f'({x1}, {y1}) to ({x2}, {y2})'
                            detected_safety = DetectedVehicle(
                                frame_number=frame_number,
                                class_name=classnames[Class],
                                confidence=confidence,
                                coordinates=coordinates
                            )
                            detected_safety.save()

                            # Print status
                            print(f"Detected: {classnames[Class]}, Confidence: {confidence}, Coordinates: {coordinates}")
                            
                        
                            
                        
                            
                            
                        else:
                            print("No Data")
                            
                    else:
                            print("No Data")
                            

            cv2.imshow('frame', frame)
            k = cv2.waitKey(1)
            if k == 27:
                break
        cv2.destroyAllWindows()
        saved_Safety = DetectedVehicle.objects.all()

        return render(request, '9_Deploy.html', {"PREDICTION":cv2.imshow('frame', frame),"saved_Safety": saved_Safety})
    
    else:
        return render(request, '9_Deploy.html')

from APP.models import DetectedVehicle
    
def Per_Database_10(request):
    models = DetectedVehicle.objects.all()
    return render(request, '10_Per_Database.html', {'models':models})

def Logout(request):
    logout(request)
    return redirect('Login_3')
